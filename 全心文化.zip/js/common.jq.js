$(function(){

  // navbar on mobile hover
  $('.navbar-mobile .menu-list>li').has('.sublist').hover(function () {
    var $subli=$('.sublist',this).children();
    $(this).css('height', $subli.length*$subli.css('height').slice(0,-2));
  }, function () {
    $(this).removeAttr('style');
  }).click(function (e) {
    e ? e.preventDefault() : window.event.returnValue = false;
    var $subli=$('.sublist',this).children();
    $(this).css('height', $subli.length*$subli.css('height').slice(0,-2)).siblings().removeAttr('style');
  });

  // menu-list hover
  $('.navbar-menu .menu-list>li').has('.sublist').hover(function () {
    $(this).find('.sublist').fadeIn();
  }, function () {
    $(this).find('.sublist').hide();
  });
})
